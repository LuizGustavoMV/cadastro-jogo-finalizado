# Apresentação do projeto: Cadastro de Jogos

Este documento é um roteiro para explicar como a tela React conversa com a API Java e como demonstrar os recursos usando o próprio código do projeto.

## 1. Como as partes se conectam

O backend é uma aplicação Spring Boot. O controller `src/main/java/com/Jogo/cadastro_jogo/controller/JogoController.java` recebe requisições HTTP no caminho `/jogo` e delega as operações ao `JogoService`. O serviço usa o repositório Spring Data JPA para persistir e consultar a entidade `Jogo`.

O frontend vive separadamente em `frontend/`. O componente `frontend/src/App.jsx` apresenta os formulários e a coleção. Em vez de chamar `fetch` em vários componentes, a tela usa as funções concentradas em `frontend/src/api.js`. Essa separação facilita explicar e manter a comunicação com a API.

A origem da API não está espalhada pela interface. `frontend/src/api.js` lê `VITE_API_BASE_URL` e, caso a variável não exista, usa `http://localhost:8080`. Por exemplo, `jogosApi.listar()` envia um `GET` para `${API_BASE_URL}/jogo`; `jogosApi.criar(jogo)` envia `POST` para o mesmo caminho e serializa os dados em JSON.

O controller habilita CORS somente para `http://localhost:5173`, endereço local padrão do Vite. CORS é a permissão do navegador para uma página em uma origem chamar uma API em outra origem. Se a interface for hospedada em outro domínio, a origem precisa ser configurada de modo compatível no backend.

## 2. Como os métodos HTTP são usados

| Ação que a pessoa faz | Método e rota | Exemplo de código | O que volta |
| --- | --- | --- | --- |
| Abrir ou atualizar a coleção | `GET /jogo` | `jogosApi.listar(filtros)` em `frontend/src/api.js` | Array JSON de jogos. |
| Procurar um ID | `GET /jogo/{id}` | `jogosApi.buscarPorId(id)` | Um objeto `Jogo`, ou erro 404 se não existir. |
| Cadastrar | `POST /jogo` | `jogosApi.criar(payload)` | `201 Created` e o jogo salvo. |
| Salvar alterações | `PUT /jogo/{id}` | `jogosApi.atualizar(id, payload)` | O objeto atualizado. O serviço atualiza apenas propriedades que não sejam `null`. |
| Excluir | `DELETE /jogo/{id}` | `jogosApi.excluir(id)` | `204 No Content`, ou seja, não há corpo na resposta. |

Ao cadastrar, `frontend/src/App.jsx` prepara um objeto com as propriedades `nome`, `genero`, `preco` e `plataforma`. `preco` é convertido para número (`Number(form.preco)`) ou enviado como `null` quando o campo fica vazio. O `id` não é informado pelo formulário porque `Jogo.id` é gerado no backend/banco.

Na listagem, `applyFilters` monta parâmetros opcionais. Os parâmetros textuais implementados pelo serviço fazem correspondência parcial sem distinguir maiúsculas de minúsculas. O parâmetro `preco` é uma igualdade exata, não “menor ou igual”; por isso a interface o identifica como “Preço exato”. Quando mais de um filtro é informado, o serviço combina os critérios.

No `PUT`, um preço vazio é enviado como `null`. O código do serviço `JogoService.atualizarJogoPorId` ignora propriedades nulas, então esse campo vazio mantém o preço anterior; não significa apagar o preço. Essa descrição acompanha a implementação existente, sem inventar uma regra diferente.

## 3. Respostas, carregamento e atualização da interface

Em `frontend/src/api.js`, a função `request`:

1. executa `fetch` com a URL-base configurada;
2. adiciona `Content-Type: application/json` quando há corpo;
3. interpreta o corpo JSON, se houver;
4. trata `204 No Content` sem tentar interpretar JSON;
5. transforma respostas HTTP de erro e falhas de conexão em mensagens compreensíveis.

Em `frontend/src/App.jsx`, `loadGames` controla o estado de carregamento, atualiza a lista e apresenta falhas. Após criar, editar ou excluir, a tela chama a operação da API e recarrega a coleção automaticamente com `loadGames(activeFilters)`, sem exigir atualização manual do navegador. As mensagens de sucesso e erro aparecem na própria página.

## 4. Como demonstrar ao professor

1. Inicie o PostgreSQL configurado no `application.properties` e rode `./mvnw spring-boot:run` na raiz.
2. Em outro terminal, rode `cd frontend`, `npm install` e `npm run dev`; abra `http://localhost:5173`.
3. Demonstre o cadastro preenchendo um ou mais campos e clicando em **Cadastrar jogo**. Observe a requisição `POST` e o novo item na coleção.
4. Use os filtros de nome, gênero e plataforma como busca por trecho; para preço, informe o valor exato. Mostre também **Limpar**.
5. Digite um ID em **Buscar por ID** para demonstrar `GET /jogo/{id}`.
6. Clique no ícone de edição de um jogo, altere um campo e salve para demonstrar `PUT` e a atualização da tela.
7. Clique no ícone de exclusão e confirme para demonstrar `DELETE` e a remoção imediata da lista.
8. Se a API estiver desligada, observe a mensagem de conexão. Pode-se também buscar um ID inexistente para observar o erro retornado pelo backend.

## 5. Como o prompt orientou a interface

A interface foi construída seguindo os limites pedidos: o backend foi inspecionado antes da implementação; somente as cinco operações declaradas em `JogoController` são usadas; os campos vêm da entidade `Jogo`; a URL é configurável por variável de ambiente; as chamadas HTTP foram centralizadas; e os fluxos mostram carregamento, sucesso e erro. A tela adapta seu layout a diferentes larguras e não inclui campos ou regras de negócio que não existam no código Java.
