# Cadastro de Jogos

Aplicação full stack para cadastrar e consultar uma coleção de jogos. O backend expõe uma API REST em Spring Boot; o frontend, separado em `frontend/`, foi construído com React, Vite, JavaScript e CSS responsivo.

## Tecnologias

- **Backend:** Java 26 (versão definida no `pom.xml`), Spring Boot, Spring Web MVC, Spring Data JPA, PostgreSQL e Maven Wrapper.
- **Frontend:** React, Vite, JavaScript e CSS.
- **Entidade persistida:** `Jogo`, com `id` (Integer gerado pelo banco), `nome` (String), `genero` (String), `preco` (Double) e `plataforma` (String).

## Executar o backend

1. Instale Java 26 e tenha PostgreSQL disponível localmente.
2. Configure a conexão definida em `src/main/resources/application.properties` (por padrão, `jdbc:postgresql://localhost:5432/postgres`, usuário `postgres`, senha `postgres`).
3. Na raiz do repositório, execute:

   ```bash
   ./mvnw spring-boot:run
   ```

O backend inicia por padrão na porta `8080`. Para executar os testes automatizados:

```bash
./mvnw test
```

> A configuração de banco acima é a que já estava no projeto. O frontend não cria nem altera tabelas ou regras de persistência.

## Executar o frontend

Em outro terminal:

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Abra `http://localhost:5173`. O `.env` contém a URL-base do backend; por padrão:

```env
VITE_API_BASE_URL=http://localhost:8080
```

Se o backend estiver em outra URL, altere `VITE_API_BASE_URL` e reinicie o servidor Vite. A variável é compilada no frontend e deve conter somente uma URL pública, nunca credenciais.

Para validar a compilação de produção:

```bash
cd frontend
npm run build
```

## Endpoints consumidos pelo frontend

Todas as rotas estão sob `/jogo`. A URL-base vem de `VITE_API_BASE_URL`.

| Método | Caminho | Uso no frontend | Contrato relevante |
| --- | --- | --- | --- |
| `GET` | `/jogo` | Listar e filtrar | Query params opcionais: `nome`, `genero`, `plataforma` (trecho sem distinção entre maiúsculas/minúsculas) e `preco` (igualdade exata). Filtros combinados são aplicados em conjunto. Retorna uma lista de jogos. |
| `GET` | `/jogo/{id}` | Buscar por ID | Retorna um jogo; o serviço lança `404` com a mensagem `Jogo não encontrado` quando não existe. |
| `POST` | `/jogo` | Cadastrar | Recebe JSON com `nome`, `genero`, `preco` e `plataforma`; responde `201 Created` com o jogo salvo. O `id` é gerado pela persistência. |
| `PUT` | `/jogo/{id}` | Editar | Recebe um objeto `Jogo` e responde com o registro atualizado. O serviço só substitui propriedades não nulas; assim, um `preco: null` não limpa o preço existente. |
| `DELETE` | `/jogo/{id}` | Excluir | Remove o jogo e responde `204 No Content`. |

Não foram encontrados DTOs nem anotações de validação de campos no backend; os formulários refletem os nomes e tipos da entidade e validam que o preço, quando preenchido, seja numérico. O frontend não presume preço mínimo ou campos obrigatórios não definidos na API.

## CORS

O controller `JogoController` agora permite a origem `http://localhost:5173` via `@CrossOrigin`, que é a alteração mínima para o Vite local chamar diretamente o backend em `localhost:8080`. Se o frontend for servido por outra origem, ajuste essa origem permitida no controller. Nenhum endpoint ou regra de negócio foi alterado.

## Estrutura

```text
src/                         Backend Spring Boot existente
frontend/                    Aplicação React/Vite
  public/manus-routes.json   Rota pública da interface
  src/api.js                 Cliente HTTP centralizado
  src/App.jsx                Telas e fluxos do CRUD
  src/styles.css             Layout responsivo
APRESENTACAO.md              Roteiro explicativo para demonstração
```
