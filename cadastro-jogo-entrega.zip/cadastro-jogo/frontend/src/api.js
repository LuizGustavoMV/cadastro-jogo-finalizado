const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080').replace(/\/$/, '');

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers: {
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...options.headers,
      },
    });
  } catch {
    throw new Error(`Não foi possível conectar à API em ${API_BASE_URL}. Confira se o backend está em execução e se VITE_API_BASE_URL está correto.`);
  }

  if (response.status === 204) return null;

  const rawBody = await response.text();
  let body = null;
  if (rawBody) {
    try {
      body = JSON.parse(rawBody);
    } catch {
      body = rawBody;
    }
  }

  if (!response.ok) {
    const detail = typeof body === 'string'
      ? body
      : body?.message || body?.detail || body?.error;
    throw new Error(detail || `A API respondeu com erro HTTP ${response.status}.`);
  }

  return body;
}

function toQueryString(filters) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value !== undefined && value !== null && String(value).trim() !== '') {
      query.set(key, String(value).trim());
    }
  }
  const serialized = query.toString();
  return serialized ? `?${serialized}` : '';
}

export const jogosApi = {
  listar: (filtros = {}) => request(`/jogo${toQueryString(filtros)}`),
  buscarPorId: (id) => request(`/jogo/${encodeURIComponent(id)}`),
  criar: (jogo) => request('/jogo', { method: 'POST', body: JSON.stringify(jogo) }),
  atualizar: (id, jogo) => request(`/jogo/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(jogo),
  }),
  excluir: (id) => request(`/jogo/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

export const apiBaseUrl = API_BASE_URL;
