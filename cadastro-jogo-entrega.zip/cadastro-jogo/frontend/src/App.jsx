import { useCallback, useEffect, useMemo, useState } from 'react';
import { apiBaseUrl, jogosApi } from './api.js';

const EMPTY_GAME = { nome: '', genero: '', preco: '', plataforma: '' };

function Icon({ name, size = 18 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true };
  const paths = {
    plus: <><path d="M12 5v14M5 12h14" /></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.2 4.2" /></>,
    game: <><path d="M6.5 8h11a4.5 4.5 0 0 1 4.4 5.5l-.8 3.3a2.5 2.5 0 0 1-4.1 1.3L14.7 16H9.3l-2.3 2.1a2.5 2.5 0 0 1-4.1-1.3l-.8-3.3A4.5 4.5 0 0 1 6.5 8Z" /><path d="M7 11v4M5 13h4M16 12h.01M19 14h.01" /></>,
    edit: <><path d="m15 5 4 4M4 20l4-.8L19 8a2.1 2.1 0 0 0-3-3L5 16l-1 4Z" /></>,
    trash: <><path d="M4 7h16M10 11v6M14 11v6M5.5 7l1 13h11l1-13M9 7V4h6v3" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    refresh: <><path d="M20 7v5h-5M4 17v-5h5" /><path d="M5.5 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.5-3" /></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function gameToForm(game = {}) {
  return {
    nome: game.nome ?? '',
    genero: game.genero ?? '',
    preco: game.preco ?? '',
    plataforma: game.plataforma ?? '',
  };
}

function validateForm(form) {
  if (form.preco !== '' && (!Number.isFinite(Number(form.preco)))) {
    return 'O preço deve ser um número válido.';
  }
  return '';
}

function priceLabel(price) {
  if (price === null || price === undefined || price === '') return '—';
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(price));
}

function GameForm({ title, initialValue, submitLabel, onSubmit, onCancel, busy }) {
  const [form, setForm] = useState(() => gameToForm(initialValue));
  const [error, setError] = useState('');

  useEffect(() => {
    setForm(gameToForm(initialValue));
    setError('');
  }, [initialValue]);

  function change(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  async function submit(event) {
    event.preventDefault();
    const validationError = validateForm(form);
    if (validationError) {
      setError(validationError);
      return;
    }
    setError('');
    const payload = {
      nome: form.nome,
      genero: form.genero,
      preco: form.preco === '' ? null : Number(form.preco),
      plataforma: form.plataforma,
    };
    await onSubmit(payload);
  }

  return (
    <form className="game-form" onSubmit={submit}>
      <div className="form-fields">
        <label>Nome do jogo<input name="nome" value={form.nome} onChange={change} placeholder="Ex.: Stardew Valley" autoComplete="off" /></label>
        <label>Gênero<input name="genero" value={form.genero} onChange={change} placeholder="Ex.: Simulação" autoComplete="off" /></label>
        <label>Plataforma<input name="plataforma" value={form.plataforma} onChange={change} placeholder="Ex.: PC" autoComplete="off" /></label>
        <label>Preço<input name="preco" type="number" inputMode="decimal" step="any" value={form.preco} onChange={change} placeholder="Ex.: 59.90" /></label>
      </div>
      {error && <p className="inline-error" role="alert">{error}</p>}
      <div className="form-actions">
        {onCancel && <button className="button button-quiet" type="button" onClick={onCancel}>Cancelar</button>}
        <button className="button button-primary" type="submit" disabled={busy}>
          {busy ? 'Salvando…' : submitLabel}
        </button>
      </div>
    </form>
  );
}

function App() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [createFormVersion, setCreateFormVersion] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const [filters, setFilters] = useState({ nome: '', genero: '', plataforma: '', preco: '' });
  const [activeFilters, setActiveFilters] = useState({});
  const [editingGame, setEditingGame] = useState(null);
  const [lookupId, setLookupId] = useState('');
  const [lookupResult, setLookupResult] = useState(null);
  const [lookupLoading, setLookupLoading] = useState(false);

  const loadGames = useCallback(async (currentFilters = {}) => {
    setLoading(true);
    try {
      const data = await jogosApi.listar(currentFilters);
      setGames(Array.isArray(data) ? data : []);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadGames(); }, [loadGames]);

  const totalLabel = useMemo(() => `${games.length} ${games.length === 1 ? 'jogo encontrado' : 'jogos encontrados'}`, [games.length]);

  function handleFilterChange(event) {
    setFilters((current) => ({ ...current, [event.target.name]: event.target.value }));
  }

  async function applyFilters(event) {
    event.preventDefault();
    if (filters.preco !== '' && !Number.isFinite(Number(filters.preco))) {
      setFeedback({ type: 'error', text: 'O preço do filtro deve ser um número válido.' });
      return;
    }
    const next = { ...filters, preco: filters.preco === '' ? '' : Number(filters.preco) };
    setActiveFilters(next);
    setFeedback(null);
    await loadGames(next);
  }

  async function clearFilters() {
    const cleared = { nome: '', genero: '', plataforma: '', preco: '' };
    setFilters(cleared);
    setActiveFilters({});
    setFeedback(null);
    await loadGames({});
  }

  async function createGame(payload) {
    setBusy(true);
    try {
      await jogosApi.criar(payload);
      setFeedback({ type: 'success', text: 'Jogo cadastrado com sucesso.' });
      setCreateFormVersion((version) => version + 1);
      await loadGames(activeFilters);
      return true;
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function updateGame(payload) {
    if (!editingGame) return false;
    setBusy(true);
    try {
      const saved = await jogosApi.atualizar(editingGame.id, payload);
      setFeedback({ type: 'success', text: `Jogo #${editingGame.id} atualizado com sucesso.` });
      setEditingGame(null);
      if (lookupResult?.id === editingGame.id) setLookupResult(saved);
      await loadGames(activeFilters);
      return true;
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function deleteGame(game) {
    if (!window.confirm(`Excluir “${game.nome || `jogo #${game.id}`}”? Esta ação não pode ser desfeita.`)) return;
    setBusy(true);
    try {
      await jogosApi.excluir(game.id);
      setFeedback({ type: 'success', text: `Jogo #${game.id} excluído com sucesso.` });
      if (lookupResult?.id === game.id) setLookupResult(null);
      if (editingGame?.id === game.id) setEditingGame(null);
      await loadGames(activeFilters);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setBusy(false);
    }
  }

  async function lookupGame(event) {
    event.preventDefault();
    if (!/^\d+$/.test(lookupId.trim())) {
      setFeedback({ type: 'error', text: 'Informe um ID inteiro para buscar um jogo.' });
      return;
    }
    setLookupLoading(true);
    setLookupResult(null);
    try {
      const result = await jogosApi.buscarPorId(lookupId.trim());
      setLookupResult(result);
      setFeedback(null);
    } catch (error) {
      setFeedback({ type: 'error', text: error.message });
    } finally {
      setLookupLoading(false);
    }
  }

  function beginEdit(game) {
    setEditingGame(game);
    document.getElementById('edit-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Playlog — início">
          <span className="brand-mark"><Icon name="game" size={21} /></span>
          <span>play<span className="brand-accent">log</span></span>
        </a>
        <div className="api-status"><span className="status-dot" /> API configurada <code>{apiBaseUrl}</code></div>
      </header>

      <main id="inicio" className="page-content">
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow">SUA ESTANTE, EM UM SÓ LUGAR</p>
            <h1>Uma coleção para <span>jogar de novo.</span></h1>
            <p className="hero-subtitle">Organize seus jogos e encontre exatamente o que procura.</p>
          </div>
          <div className="hero-stamp" aria-hidden="true"><span>GAME<br />LIBRARY</span><Icon name="game" size={28} /></div>
        </section>

        {feedback && (
          <div className={`feedback feedback-${feedback.type}`} role={feedback.type === 'error' ? 'alert' : 'status'}>
            <span className="feedback-mark">{feedback.type === 'error' ? '!' : '✓'}</span>
            <span>{feedback.text}</span>
            <button type="button" className="feedback-close" onClick={() => setFeedback(null)} aria-label="Fechar mensagem"><Icon name="close" size={16} /></button>
          </div>
        )}

        <div className="workspace">
          <aside className="side-column">
            <section className="panel create-panel">
              <div className="panel-heading">
                <span className="heading-icon"><Icon name="plus" /></span>
                <div><h2>Novo jogo</h2><p>Adicione à sua coleção</p></div>
              </div>
              <GameForm key={createFormVersion} title="Novo jogo" initialValue={EMPTY_GAME} submitLabel="Cadastrar jogo" onSubmit={createGame} busy={busy} />
            </section>

            <section className="panel lookup-panel">
              <div className="panel-heading compact-heading">
                <span className="heading-icon muted-icon"><Icon name="search" /></span>
                <div><h2>Buscar por ID</h2><p>Consulte um registro específico</p></div>
              </div>
              <form className="lookup-form" onSubmit={lookupGame}>
                <label className="sr-only" htmlFor="lookup-id">ID do jogo</label>
                <input id="lookup-id" value={lookupId} onChange={(event) => setLookupId(event.target.value)} placeholder="Ex.: 12" inputMode="numeric" />
                <button type="submit" className="icon-button search-button" aria-label="Buscar jogo" disabled={lookupLoading}><Icon name="arrow" /></button>
              </form>
              {lookupLoading && <p className="lookup-note">Buscando jogo…</p>}
              {lookupResult && <div className="lookup-result">
                <div><span className="result-id">#{lookupResult.id}</span><strong>{lookupResult.nome || 'Jogo sem nome'}</strong></div>
                <p>{[lookupResult.genero, lookupResult.plataforma].filter(Boolean).join(' · ') || 'Sem gênero ou plataforma informados'}</p>
                <div className="lookup-result-bottom"><span>{priceLabel(lookupResult.preco)}</span><button className="text-button" type="button" onClick={() => beginEdit(lookupResult)}>Editar <Icon name="arrow" size={14} /></button></div>
              </div>}
            </section>
          </aside>

          <div className="main-column">
            <section className="panel filter-panel">
              <div className="filter-header"><div><p className="eyebrow">ENCONTRE NA COLEÇÃO</p><h2>Filtrar jogos</h2></div><span className="filter-symbol"><Icon name="search" size={22} /></span></div>
              <form className="filter-form" onSubmit={applyFilters}>
                <label>Nome<input name="nome" value={filters.nome} onChange={handleFilterChange} placeholder="Buscar por nome" /></label>
                <label>Gênero<input name="genero" value={filters.genero} onChange={handleFilterChange} placeholder="Ex.: Aventura" /></label>
                <label>Plataforma<input name="plataforma" value={filters.plataforma} onChange={handleFilterChange} placeholder="Ex.: PC, PS5" /></label>
                <label>Preço exato<input name="preco" type="number" inputMode="decimal" step="any" value={filters.preco} onChange={handleFilterChange} placeholder="Ex.: 49.90" /></label>
                <div className="filter-actions"><button className="button button-primary" type="submit"><Icon name="search" size={16} /> Aplicar filtros</button><button className="button button-quiet" type="button" onClick={clearFilters}>Limpar</button></div>
              </form>
              <p className="filter-hint">Os filtros de texto procuram trechos sem diferenciar maiúsculas de minúsculas. O preço corresponde ao valor exato.</p>
            </section>

            <section className="collection-section">
              <div className="collection-heading"><div><p className="eyebrow">BIBLIOTECA</p><h2>Sua coleção <span className="count-badge">{games.length}</span></h2></div><button className="button button-quiet refresh-button" type="button" onClick={() => loadGames(activeFilters)} disabled={loading}><Icon name="refresh" size={16} /> Atualizar</button></div>
              <div className="collection-meta"><span>{loading ? 'Carregando coleção…' : totalLabel}</span>{Object.values(activeFilters).some((value) => String(value).trim()) && <span className="filter-applied">Filtros ativos</span>}</div>

              {loading ? <div className="loading-state"><span className="spinner" />Carregando jogos da API…</div> : games.length === 0 ? (
                <div className="empty-state"><span className="empty-icon"><Icon name="game" size={26} /></span><h3>{Object.values(activeFilters).some(Boolean) ? 'Nenhum jogo corresponde aos filtros' : 'Sua coleção começa aqui'}</h3><p>{Object.values(activeFilters).some(Boolean) ? 'Experimente mudar os critérios da busca.' : 'Cadastre um jogo no formulário para vê-lo aparecer nesta lista.'}</p></div>
              ) : <div className="game-list">
                {games.map((game, index) => <article className="game-card" key={game.id ?? `${game.nome}-${index}`}>
                  <div className="game-art" aria-hidden="true"><span>{game.nome?.trim()?.charAt(0)?.toUpperCase() || 'J'}</span></div>
                  <div className="game-details"><div className="game-title-line"><h3>{game.nome || 'Jogo sem nome'}</h3><span className="game-id">#{game.id}</span></div><p className="game-tags">{[game.genero, game.plataforma].filter(Boolean).join(' · ') || 'Sem gênero ou plataforma informados'}</p><div className="game-card-bottom"><span className="game-price">{priceLabel(game.preco)}</span><div className="card-actions"><button className="icon-button" type="button" onClick={() => beginEdit(game)} aria-label={`Editar ${game.nome}`} title="Editar"><Icon name="edit" size={17} /></button><button className="icon-button danger-button" type="button" onClick={() => deleteGame(game)} disabled={busy} aria-label={`Excluir ${game.nome}`} title="Excluir"><Icon name="trash" size={17} /></button></div></div></div>
                </article>)}
              </div>}
            </section>
          </div>
        </div>

        {editingGame && <section id="edit-panel" className="panel edit-panel">
          <div className="panel-heading edit-heading"><span className="heading-icon"><Icon name="edit" /></span><div><h2>Editar jogo <span className="edit-id">#{editingGame.id}</span></h2><p>Os campos enviados atualizam o registro existente.</p></div><button className="icon-button close-edit" type="button" onClick={() => setEditingGame(null)} aria-label="Cancelar edição"><Icon name="close" /></button></div>
          <GameForm key={editingGame.id} title="Editar jogo" initialValue={editingGame} submitLabel="Salvar alterações" onSubmit={updateGame} onCancel={() => setEditingGame(null)} busy={busy} />
        </section>}

        <footer className="footer"><span>PLAYLOG <span className="footer-dot">·</span> CADASTRO DE JOGOS</span><span>Conectado a <code>{apiBaseUrl}</code></span></footer>
      </main>
    </div>
  );
}

export default App;
